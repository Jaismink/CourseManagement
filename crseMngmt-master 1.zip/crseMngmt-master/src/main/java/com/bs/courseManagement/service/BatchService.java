package com.bs.courseManagement.service;

import com.bs.courseManagement.model.Batch;
import com.bs.courseManagement.repository.BatchRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BatchService {

    @Autowired
    private BatchRepository batchRepository;

    public Batch createBatch(Batch batch) {
        return batchRepository.save(batch);
    }

    public Batch updateBatch(int id, Batch batch) {
        batch.setBatchId(id);
        return batchRepository.save(batch);
    }

    public void deleteBatch(int id) {
        batchRepository.deleteById(id);
    }

    public Batch getBatchById(int id) {
        return batchRepository.findById(id).orElse(null);
    }

    public List<Batch> getAllBatches() {
        return batchRepository.findAll();
    }
}
