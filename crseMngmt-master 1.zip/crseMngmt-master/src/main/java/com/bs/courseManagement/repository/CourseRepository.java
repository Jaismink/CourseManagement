package com.bs.courseManagement.repository;

import com.bs.courseManagement.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CourseRepository extends JpaRepository<Course, Integer> {
    // You can define custom queries here if needed
}