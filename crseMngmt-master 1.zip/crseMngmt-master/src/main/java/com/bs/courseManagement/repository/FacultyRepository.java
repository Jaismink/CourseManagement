package com.bs.courseManagement.repository;

import com.bs.courseManagement.model.Faculty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FacultyRepository extends JpaRepository<Faculty, Integer> {
    // You can define custom queries here if needed
}