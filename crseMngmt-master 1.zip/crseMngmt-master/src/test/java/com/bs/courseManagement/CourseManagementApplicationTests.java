package com.bs.courseManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
